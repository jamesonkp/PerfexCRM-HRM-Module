"use strict";
var hidden_columns = [4,5,8,9,10,11];